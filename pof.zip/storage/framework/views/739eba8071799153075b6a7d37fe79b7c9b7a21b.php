<?php $__env->startSection('content'); ?>
<div class=" col-md-9 category">

    <h1>Edit Team <?php echo e($team->teamId); ?></h1>

    <?php echo Form::model($team, [
        'method' => 'PATCH',
        'url' => ['/team', $team->teamId],
        'class' => 'form-horizontal'
    ]); ?>


                <div class="form-group <?php echo e($errors->has('teamId') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamId', 'Teamid', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamId', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('teamId', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamName') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamName', 'Team Name', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamName', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('teamName', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamLocation') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamLocation', 'Team Location', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamLocation', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('teamLocation', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamLeader') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamLeader', 'Team Leader', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamLeader', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('teamLeader', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamCreationDate') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamCreationDate', 'Team Creation Date', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamCreationDate', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('teamCreationDate', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamEndDate') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamEndDate', 'Team End Date', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamEndDate', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('teamEndDate', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('teamcode') ? 'has-error' : ''); ?>">
                <?php echo Form::label('teamCode', 'Team Code', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('teamCode', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('teamCode', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <?php echo Form::label('description', 'Description', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('description', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('deleted') ? 'has-error' : ''); ?>">
                <?php echo Form::label('deleted', 'Deleted', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('deleted', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('deleted', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                <?php echo Form::label('status', 'Status', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('status', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>