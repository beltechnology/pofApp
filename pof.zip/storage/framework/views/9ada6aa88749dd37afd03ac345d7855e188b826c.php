<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>employee <?php echo e($employee->employeeId); ?>

        <a href="<?php echo e(url('employee/' . $employee->employeeId . '/edit')); ?>" class="btn btn-primary btn-xs" title="Edit employee"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
        <?php echo Form::open([
            'method'=>'DELETE',
            'url' => ['employee', $employee->employeeId],
            'style' => 'display:inline'
        ]); ?>

            <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true"/>', array(
                    'type' => 'submit',
                    'class' => 'btn btn-danger btn-xs',
                    'title' => 'Delete employee',
                    'onclick'=>'return confirm("Confirm delete?")'
            ));; ?>

        <?php echo Form::close(); ?>

    </h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <tbody>
                <tr>
                    <th>ID</th><td><?php echo e($employee->employeeId); ?></td>
                </tr>
                <tr><th> EmployeeId </th><td> <?php echo e($employee->employeeId); ?> </td></tr><tr><th> EntityId </th><td> <?php echo e($employee->entityId); ?> </td></tr><tr><th> DateOfJoining </th><td> <?php echo e($employee->dateOfJoining); ?> </td></tr>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>