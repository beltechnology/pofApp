     </div>
      </div>
       </div>
 </section>
  <section id="footer">
        <div class="container">
            <div class="row">
            
            <div class="main-footer col-md-12">
            
            <div class="copyright col-md-3">
            <p>&copy <?php echo e(trans('messages.COPYRIGHT')); ?> <?php echo date('Y') ?></p>
            </div>
            
            <div class="bel-techno col-md-6">
            <p><?php echo e(trans('messages.CREATED_AND_MAINTAINED')); ?></p>
            </div>
            
            <div class=" reserved col-md-3">
            <p><?php echo e(trans('messages.ALL_RIGHTS_RESERVED')); ?></p>
            </div>
            
          	</div>
       </div>
  </div>
 </section>
</body>
</html>
