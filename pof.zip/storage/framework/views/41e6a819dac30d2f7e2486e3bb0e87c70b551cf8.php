<?php $__env->startSection('content'); ?>
<div class=" col-md-9 category">
    <h1>Create New employee</h1>
    <hr/>
<div class="row">
    <?php echo Form::open(['url' => '/employee', 'class' => 'form-horizontal']); ?>

    			<div class=" col-md-6">
                    <?php echo Form::hidden('employeeId',\DB::table('employees')->max('employeeId')+1, null, ['class' => 'form-control','required' => 'required'],['name'=>'employeeid']); ?>

                
                    <?php echo Form::hidden('entityId',\DB::table('entitys')->max('entityId')+1, null, ['class' => 'form-control','required' => 'required'],['name'=>'entityId']); ?>

               
                     
            <div class="form-group <?php echo e($errors->has('employeeName') ? 'has-error' : ''); ?>">
                <?php echo Form::label('employeeName', 'Name', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('employeeName', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('employeeName', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('dob') ? 'has-error' : ''); ?>">
                <?php echo Form::label('dob', 'Dob', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('dob', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('dob', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>   
             <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <?php echo Form::label('address', 'Address', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('address', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>      
            <div class="form-group <?php echo e($errors->has('state') ? 'has-error' : ''); ?>">
                <?php echo Form::label('state', 'State', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
					<?php echo Form::select('state',\DB::table('states')->lists('name','id'), "Debugging", ['class' => 'form-control stateSelect','placeholder' => 'Select a State','id' => 'stateSelect']); ?>

                    <?php echo $errors->first('state', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
			 <div class="form-group <?php echo e($errors->has('district') ? 'has-error' : ''); ?>">
                <?php echo Form::label('district', 'District', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
					<?php echo Form::select('district', array('key' => 'value'), 'key', array('class' => 'form-control','id'=>'selectCity', 'placeholder' => 'City')); ?>

					 <?php echo $errors->first('district', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
             <div class="form-group <?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
                <?php echo Form::label('city', 'City', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
					<?php echo Form::select('city', array('key' => 'value'), 'key', array('class' => 'form-control','id'=>'selectCity', 'placeholder' => 'City')); ?>

					 <?php echo $errors->first('city', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
             <div class="form-group <?php echo e($errors->has('pinCode') ? 'has-error' : ''); ?>">
                <?php echo Form::label('pinCode', 'Pin Code', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('pinCode', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('pinCode', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            
             </div>
            <div class=" col-md-6">
            
             <div class="form-group <?php echo e($errors->has('primaryMobile') ? 'has-error' : ''); ?>">
                <?php echo Form::label('primaryMobile', 'Primary Mobile', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('primaryMobile', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('primaryMobile', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
             <div class="form-group <?php echo e($errors->has('secondaryMobile') ? 'has-error' : ''); ?>">
                <?php echo Form::label('secondaryMobile', 'Secondary Mobile', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('secondaryMobile', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('secondaryMobile', '<p class="help-block">:message</p>'); ?>

                </div>
            </div> 
            <div class="form-group <?php echo e($errors->has('emailAddress') ? 'has-error' : ''); ?>">
                <?php echo Form::label('emailAddress', 'Employee Email Id', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('emailAddress', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('emailAddress', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            
              <div class="form-group <?php echo e($errors->has('designation') ? 'has-error' : ''); ?>">
                <?php echo Form::label('designation', 'Designation', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('designation', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('designation', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('dateOfJoining') ? 'has-error' : ''); ?>">
                <?php echo Form::label('dateOfJoining', 'Date Of Joining', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('dateOfJoining', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('dateOfJoining', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            </div>
            <!--<div class="form-group <?php echo e($errors->has('employeeCode') ? 'has-error' : ''); ?>">
                <?php echo Form::label('employeeCode', 'Employee Code', ['class' => 'col-sm-5  control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('employeeCode', null, ['class' => 'form-control','required' => 'required']); ?>

                    <?php echo $errors->first('employeeCode', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
			 -->
              <div class=" col-md-6">
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-5 ">
            <?php echo Form::reset('Cancel', ['class' => 'btn btn-primary ']); ?>

            <?php echo Form::submit('Submit', ['class' => 'btn btn-primary ']); ?>

        </div>
    </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>