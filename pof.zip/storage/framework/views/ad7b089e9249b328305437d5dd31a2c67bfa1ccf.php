<?php $__env->startSection('content'); ?>
<div class=" col-md-9 category">
    <h1>Employee <a href="<?php echo e(url('/employee/create')); ?>" class="btn btn-primary btn-xs" title="Add New employee"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a></h1>
    <div class="main-table col-md">
            <table border="0" bgcolor="#eeeeee">
            <thead bgcolor="#ffffff" style="color:#4b4b4b">
      <tr class="table-heading">
        <th width="200" class="emp-name"><span><i class="fa fa-square-o" aria-hidden="true"></i></span>Employee Name</th>
        <th width="80" class="emp-id">Employee Id</th>
        <th width="80" class="emp-dob">DOB</th>
        <th width="110" class="emp-no">Contact Number</th>
        <th width="200" class="emp-location">Location</th>
        <th width="75" class="emp-team">Team Name</th>
        <th width="120"></th>
      </tr>
    </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($employee as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td width="200"><?php echo e($item->employeeId); ?></td>
                    <td width="80"><?php echo e($item->employeeId); ?></td>
					<td width="80"><?php echo e($item->entityId); ?></td>
					<td width="110"><?php echo e($item->dateOfJoining); ?></td>
					<td width="200"><?php echo e($item->dateOfJoining); ?></td>
					<td width="75"><?php echo e($item->dateOfJoining); ?></td>
                    <td width="120">
                        <a href="<?php echo e(url('/employee/' . $item->employeeId)); ?>" class="btn  btn-xs" title="View employee"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"/></a>
                        <a href="<?php echo e(url('/employee/' . $item->employeeId . '/edit')); ?>" class="btn  btn-xs" title="Edit employee"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/employee', $item->employeeId],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true" title="Delete employee" />', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete employee',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            ));; ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination-wrapper"> <?php echo $employee->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>