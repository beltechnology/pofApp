            <div class=" col-md-3 ">
             <nav class="main-menu">
            <ul class="nav nav-list">
                <li>
                    <a href="#">
                    	<i class="fa fa-user fa-2x"></i>
                         Employee Creation 
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="#">
                        <i class="fa fa-users fa-2x"></i>
                         Team Creation
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                        <i class="fa fa-building-o fa-2x"></i>
                         Schools
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-newspaper-o fa-2x"></i>
                         Admit Card
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="glyphicon glyphicon-list-alt fa-2x"></i>
                         Attendance Sheet
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-certificate fa-2x"></i>
                         Participation Certificates
                        </span>
                    </a>
                </li>
                
            </ul>

        </nav>
        	
</div>