<?php $__env->startSection('content'); ?>
<div class=" col-md-9 category">

    <h1>Team <a href="<?php echo e(url('/team/create')); ?>" class="btn btn-primary btn-xs" title="Add New Team"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a></h1>
    <div class="main-table col-md">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Team Name</th><th> TeamId </th><th>Contact Number</th><th>Contact Number</th><th> Team Location </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($team as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->teamId); ?></td><td><?php echo e($item->teamName); ?></td><td><?php echo e($item->teamName); ?></td><td><?php echo e($item->teamLocation); ?></td>
                    <td>
                        <a href="<?php echo e(url('/team/' . $item->teamId)); ?>" class="btn  btn-xs" title="View Team"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"/></a>
                        <a href="<?php echo e(url('/team/' . $item->teamId. '/edit')); ?>" class="btn  btn-xs" title="Edit Team"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/team', $item->teamId],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true" title="Delete Team" />', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Team',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            ));; ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination-wrapper"> <?php echo $team->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>